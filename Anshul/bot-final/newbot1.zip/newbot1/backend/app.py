import json
import pickle
import numpy as np
import random
import tensorflow as tf
from flask import Flask, request, jsonify
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Initialize Flask app
app = Flask(__name__)

# Load trained model
model = tf.keras.models.load_model("backend/models/chatbot_model.h5")

# Load preprocessed words and classes
words = pickle.load(open("backend/models/words.pkl", "rb"))
classes = pickle.load(open("backend/models/classes.pkl", "rb"))

# Load intents
with open("backend/data/intents.json") as file:
    intents = json.load(file)

lemmatizer = WordNetLemmatizer()

# Function to preprocess user input
def preprocess_input(sentence):
    word_list = tf.keras.preprocessing.text.text_to_word_sequence(sentence)
    word_list = [lemmatizer.lemmatize(w.lower()) for w in word_list]
    bag = [1 if w in word_list else 0 for w in words]
    return np.array([bag])

# Function to predict response
def get_response(user_input):
    processed_input = preprocess_input(user_input)
    prediction = model.predict(processed_input)[0]
    predicted_index = np.argmax(prediction)
    tag = classes[predicted_index]

    # Get responses from intents.json
    for intent in intents["intents"]:
        if intent["tag"] == tag:
            return random.choice(intent["responses"])

    return "I'm sorry, I don't understand."

# Flask route for chatbot
@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("message", "")
    response = get_response(user_input)
    return jsonify({"response": response})

# Run Flask app
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
