import json
import numpy as np
import random
import pickle
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import SGD
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Load intents
with open("backend/data/intents.json") as file:
    intents = json.load(file)

# Load preprocessed words and classes
words = pickle.load(open("backend/models/words.pkl", "rb"))
classes = pickle.load(open("backend/models/classes.pkl", "rb"))

lemmatizer = WordNetLemmatizer()

# Prepare training data
training = []
output_empty = [0] * len(classes)

for intent in intents["intents"]:
    for pattern in intent["patterns"]:
        word_list = tf.keras.preprocessing.text.text_to_word_sequence(pattern)
        word_list = [lemmatizer.lemmatize(w.lower()) for w in word_list]
        
        bag = [1 if w in word_list else 0 for w in words]
        output_row = list(output_empty)
        output_row[classes.index(intent["tag"])] = 1
        
        training.append([bag, output_row])

random.shuffle(training)
training = np.array(training, dtype=object)

# Split features and labels
train_x = np.array(list(training[:, 0]))
train_y = np.array(list(training[:, 1]))

# Build the model
model = Sequential([
    Dense(128, input_shape=(len(train_x[0]),), activation="relu"),
    Dropout(0.5),
    Dense(64, activation="relu"),
    Dropout(0.5),
    Dense(len(classes), activation="softmax")
])

# Compile the model
sgd = SGD(learning_rate=0.01, momentum=0.9, nesterov=True)
model.compile(loss="categorical_crossentropy", optimizer=sgd, metrics=["accuracy"])

# Train the model
model.fit(train_x, train_y, epochs=200, batch_size=5, verbose=1)

# Save the trained model
model.save("backend/models/chatbot_model.h5")

print("Training complete. Model saved!")
