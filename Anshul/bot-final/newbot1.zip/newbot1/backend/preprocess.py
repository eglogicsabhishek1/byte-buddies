import json
import nltk
import numpy as np
import random
import pickle
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Download required NLTK data
nltk.download('punkt')
nltk.download('wordnet')

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Load intents JSON file
with open("backend/data/intents.json") as file:
    intents = json.load(file)

# Lists to store training data
words = []
classes = []
documents = []
ignore_words = ["?", "!", ".", ","]

# Process each intent
for intent in intents["intents"]:
    for pattern in intent["patterns"]:
        # Tokenize each word
        word_list = nltk.word_tokenize(pattern)
        words.extend(word_list)
        documents.append((word_list, intent["tag"]))

        # Add tag to class list if not already present
        if intent["tag"] not in classes:
            classes.append(intent["tag"])

# Lemmatize words and remove duplicates
words = [lemmatizer.lemmatize(w.lower()) for w in words if w not in ignore_words]
words = sorted(set(words))
classes = sorted(set(classes))

# Save words and classes as pickle files for later use
pickle.dump(words, open("backend/models/words.pkl", "wb"))
pickle.dump(classes, open("backend/models/classes.pkl", "wb"))

print("Preprocessing complete. Data saved!")
