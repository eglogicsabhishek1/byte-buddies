import xml.sax
import time
import re
import hashlib
import csv
import tempfile
import os
from sqlalchemy import create_engine, text, MetaData
from sqlalchemy.types import VARCHAR, DateTime
from datetime import datetime
import sys
from collections import defaultdict, OrderedDict

# MySQL Database Connection
DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"
engine = create_engine(DATABASE_URL, echo=False)
metadata = MetaData()

# Sanitization cache
sanitize_cache = {}

def sanitize_name(name):
    """Sanitize names with caching."""
    original = str(name).lower()
    if original in sanitize_cache:
        return sanitize_cache[original]
    
    sanitized = re.sub(r'\W+', '_', original)
    if len(sanitized) > 60:
        hash_suffix = hashlib.md5(original.encode()).hexdigest()[:8]
        sanitized = sanitized[:52] + "_" + hash_suffix
    if sanitized and sanitized[0].isdigit():
        sanitized = "n_" + sanitized
    if not sanitized:
        sanitized = "unnamed"
    sanitize_cache[original] = sanitized
    return sanitized

class DynamicXMLHandler(xml.sax.ContentHandler):
    def __init__(self, batch_size=5000):
        super().__init__()
        self.path = []
        self.current_text = ""
        self.records = defaultdict(list)
        self.current_records = defaultdict(OrderedDict)  # ADD MISSING ATTRIBUTE
        self.batch_size = batch_size
        self.total_processed = 0
        self.start_time = time.time()
        self.last_update_time = time.time()  # ADD MISSING ATTRIBUTE
        self.known_columns = defaultdict(set)
        self.tables_created = set()
        self.parent_ids = {}
        self.root_element = None

    def startElement(self, name, attrs):
        self.path.append(name)
        if not self.root_element:
            self.root_element = name
        depth = len(self.path)
        element_data = OrderedDict()  # USE OrderedDict
        element_data['element_name'] = name
        element_data['element_path'] = '_'.join(self.path)
        element_data['element_depth'] = depth
        if depth > 1:
            parent = self.path[-2]
            element_data['parent_element'] = parent
            if depth-1 in self.parent_ids:
                element_data['parent_id'] = self.parent_ids[depth-1]
        for attr, value in attrs.items():
            element_data[f'attr_{attr}'] = value
        self.current_records[depth] = element_data  # NOW THIS WORKS
        self.current_text = ""

    # ... rest of the class remains the same ...

def parse_xml_file(file_path):
    handler = DynamicXMLHandler()
    parser = xml.sax.make_parser()
    parser.setContentHandler(handler)
    parser.parse(file_path)

if __name__ == "__main__":
    file_path = sys.argv[1] if len(sys.argv) > 1 else input("XML file path: ")
    parse_xml_file(file_path)