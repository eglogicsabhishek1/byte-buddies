#this script making each table for every element of xml file
import xml.sax
import time
import re
import hashlib
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table, text, Float, DateTime
from sqlalchemy.sql import func
from sqlalchemy.types import TypeEngine
from sqlalchemy.orm import sessionmaker
from collections import defaultdict, OrderedDict
import datetime
import sys

# MySQL Database Connection
DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"
engine = create_engine(DATABASE_URL, echo=False)
metadata = MetaData()

# Utility functions
def sanitize_name(name):
    """Sanitize column/table names to prevent SQL errors"""
    # Remove invalid characters, replace with underscore
    name = re.sub(r'\W+', '_', str(name).lower())
    # Ensure name isn't too long (MySQL has limits)
    if len(name) > 60:
        hash_suffix = hashlib.md5(name.encode()).hexdigest()[:8]
        name = name[:52] + "_" + hash_suffix
    # Ensure name doesn't start with a number
    if name and name[0].isdigit():
        name = "n_" + name
    # Ensure it's not empty
    if not name:
        name = "unnamed"
    return name

def get_column_type(value):
    """Determine SQLAlchemy column type based on value"""
    if value is None:
        return String(255)
    
    try:
        int(value)
        return Integer
    except (ValueError, TypeError):
        try:
            float(value)
            return Float
        except (ValueError, TypeError):
            # Check for date formats
            date_formats = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y/%m/%d", "%d/%m/%Y"]
            for fmt in date_formats:
                try:
                    datetime.datetime.strptime(str(value).strip(), fmt)
                    return DateTime
                except (ValueError, TypeError):
                    continue
            return String(255)

def create_or_update_table(table_name, record):
    """Dynamically create or update tables based on XML structure"""
    table_name = sanitize_name(table_name)
    metadata.reflect(engine)
    
    # Check if table exists
    if table_name in metadata.tables:
        table = metadata.tables[table_name]
        existing_columns = set(c.name for c in table.columns)
        
        # Add missing columns
        with engine.begin() as conn:
            for col_name, value in record.items():
                sanitized_col = sanitize_name(col_name)
                if sanitized_col not in existing_columns and sanitized_col not in ["id", "record_hash", "created_at", "updated_at"]:
                    col_type = "VARCHAR(255)"  # Default type
                    
                    # Try to determine better column type
                    if value is not None:
                        try:
                            int(value)
                            col_type = "INT"
                        except (ValueError, TypeError):
                            try:
                                float(value)
                                col_type = "FLOAT"
                            except (ValueError, TypeError):
                                pass
                    
                    alter_stmt = text(f"ALTER TABLE `{table_name}` ADD COLUMN `{sanitized_col}` {col_type}")
                    try:
                        conn.execute(alter_stmt)
                        print(f"Added column: {sanitized_col} ({col_type}) to {table_name}")
                    except Exception as e:
                        print(f"Error adding column: {e}")
        
        # Refresh metadata to include new columns
        metadata.reflect(engine, only=[table_name])
        return metadata.tables[table_name]
    
    # Create new table with initial columns
    print(f"Creating new table: {table_name}")
    columns = [Column("id", Integer, primary_key=True)]
    
    # Add record_hash for deduplication
    columns.append(Column("record_hash", String(32), index=True))
    
    # Add timestamp columns for tracking
    columns.append(Column("created_at", DateTime, default=func.now()))
    columns.append(Column("updated_at", DateTime, default=func.now(), onupdate=func.now()))
    
    # Add columns from record
    for col_name, value in record.items():
        sanitized_col = sanitize_name(col_name)
        if sanitized_col not in ["id", "record_hash", "created_at", "updated_at"]:
            col_type = get_column_type(value)
            columns.append(Column(sanitized_col, col_type, nullable=True))
    
    # Create the table
    table = Table(table_name, metadata, *columns)
    metadata.create_all(engine, tables=[table])
    return table

class DynamicXMLHandler(xml.sax.ContentHandler):
    def __init__(self, batch_size=1000):
        super().__init__()
        self.path = []                # Current XML path
        self.current_text = ""        # Current element text content
        self.tables = {}              # Discovered tables
        self.records = defaultdict(list)  # Records by table
        self.current_records = defaultdict(OrderedDict)  # Track records at each depth
        self.start_time = time.time()
        self.total_processed = 0
        self.batch_size = batch_size
        self.root_element = None      # Root element name
        self.seen_paths = set()       # Track unique paths for schema discovery
        self.last_update_time = time.time()
        self.parent_ids = {}          # Track parent IDs for hierarchy
        
    def startElement(self, name, attrs):
        """Process opening XML tag"""
        # Store root element name
        if not self.root_element:
            self.root_element = name
            
        # Update path
        self.path.append(name)
        current_path = "_".join(self.path)
        depth = len(self.path)
        
        # Initialize container for this element
        element_data = OrderedDict()
        
        # Add path info for better context
        element_data['element_name'] = name
        element_data['element_path'] = current_path
        element_data['element_depth'] = depth
        
        # Store parent element for relationships (if not at root)
        if depth > 1:
            parent_name = self.path[-2]
            element_data['parent_element'] = parent_name
            
            # Link to parent ID if available
            if depth - 1 in self.parent_ids:
                element_data['parent_id'] = self.parent_ids.get(depth - 1)
        
        # Process attributes
        for attr_name, attr_value in attrs.items():
            attr_key = f"attr_{attr_name}"
            element_data[attr_key] = attr_value
            self.seen_paths.add(f"{current_path}_attr_{attr_name}")
            
            # Store ID attribute for relationship tracking
            if attr_name.lower() in ('id', 'code', 'key'):
                self.parent_ids[depth] = attr_value
                element_data['element_id'] = attr_value
        
        # Store data for this element
        self.current_records[depth] = element_data
        
        # Reset text accumulator for new element
        self.current_text = ""
    
    def characters(self, content):
        """Accumulate text content"""
        self.current_text += content
    
    def endElement(self, name):
        """Process closing XML tag"""
        depth = len(self.path)
        
        # Process accumulated text if not empty
        if self.current_text.strip():
            text_value = self.current_text.strip()
            # Store as "text_content" instead of using the path as key
            self.current_records[depth]['text_content'] = text_value
        
        # Create a record for this element if it has any data
        # Skip empty elements and the root element itself
        if depth > 1 and self.current_records[depth]:
            record = self.current_records[depth].copy()
            
            # Determine table name - use element name plus parent for better organization
            if depth > 2:
                # For deeply nested elements, use a hierarchy in the table name
                parent_element = self.path[-2]
                table_name = f"{parent_element}_{name}"
            else:
                # For direct children of root, just use their name
                table_name = name
                
            # Save this record
            self.save_record(table_name, record)
        
        # Clean up
        if depth in self.current_records:
            del self.current_records[depth]
        if depth in self.parent_ids:
            del self.parent_ids[depth]
            
        # Pop the path
        self.path.pop()
        
        # Reset text accumulator
        self.current_text = ""
    
    def save_record(self, table_name, record):
        """Save a record to its corresponding table"""
        if not record:
            return
            
        # Create a copy with sanitized keys
        sanitized_record = {}
        for key, value in record.items():
            sanitized_key = sanitize_name(key)
            sanitized_record[sanitized_key] = value
        
        # Generate hash for deduplication
        record_hash = hashlib.md5(str(sorted(sanitized_record.items())).encode()).hexdigest()
        sanitized_record["record_hash"] = record_hash
        
        # Get or create table
        if table_name not in self.tables:
            self.tables[table_name] = create_or_update_table(table_name, sanitized_record)
        else:
            # Ensure table has all necessary columns
            self.tables[table_name] = create_or_update_table(table_name, sanitized_record)
        
        # Append to records for batch processing
        self.records[table_name].append(sanitized_record)
        self.total_processed += 1
        
        # Check if we should process a batch
        total_records = sum(len(records) for records in self.records.values())
        if total_records >= self.batch_size:
            self.process_batch()
        
        # Print progress
        self.print_progress()
    
    def process_batch(self):
        """Process a batch of records"""
        for table_name, records in list(self.records.items()):
            if not records:
                continue
                
            # Get table
            table = self.tables[table_name]
            valid_columns = {c.name for c in table.columns}
            
            # Prepare valid records (only columns that exist in table)
            valid_records = []
            for record in records:
                # Filter to valid columns
                valid_record = {k: v for k, v in record.items() if k in valid_columns}
                valid_records.append(valid_record)
            
            # Bulk insert
            if valid_records:
                try:
                    with engine.begin() as conn:
                        conn.execute(table.insert(), valid_records)
                    print(f"\nInserted {len(valid_records)} records into {table_name}")
                except Exception as e:
                    print(f"\nError inserting records into {table_name}: {str(e)}")
                    
                    # Try one by one if bulk fails
                    try:
                        with engine.begin() as conn:
                            for record in valid_records:
                                try:
                                    conn.execute(table.insert().values(**record))
                                except Exception as record_e:
                                    print(f"Failed to insert record: {str(record_e)}")
                    except Exception as inner_e:
                        print(f"Failed during individual inserts: {str(inner_e)}")
        
        # Clear processed records
        self.records.clear()
    
    def print_progress(self):
        """Print progress updates"""
        current_time = time.time()
        if current_time - self.last_update_time >= 1:
            elapsed = current_time - self.start_time
            rate = self.total_processed / elapsed if elapsed > 0 else 0
            print(f"Processed: {self.total_processed} records | Rate: {rate:.2f} records/sec", end="\r")
            self.last_update_time = current_time
            
    def end_document(self):
        """Called when document parsing is complete"""
        # Process any remaining records
        if any(self.records.values()):
            self.process_batch()

# Main function
def parse_xml_file(file_path, batch_size=1000):
    """Parse an XML file and store its contents in database tables"""
    print(f"Starting to parse {file_path}...")
    handler = DynamicXMLHandler(batch_size=batch_size)
    parser = xml.sax.make_parser()
    parser.setContentHandler(handler)
    
    try:
        # Start parsing
        parser.parse(file_path)
        
        # Process any remaining records
        handler.process_batch()
        
        # Print final statistics
        elapsed = time.time() - handler.start_time
        rate = handler.total_processed / elapsed if elapsed > 0 else 0
        
        print(f"\n✅ Parsing complete!")
        print(f"📊 Total records: {handler.total_processed}")
        print(f"⏱️ Time elapsed: {elapsed:.2f} seconds")
        print(f"🚀 Average rate: {rate:.2f} records/second")
        print(f"📋 Tables created: {', '.join(handler.tables.keys())}")
        
        return True
    except Exception as e:
        print(f"\n❌ Error parsing XML: {e}")
        import traceback
        traceback.print_exc()
        return False

# If run directly
if __name__ == "__main__":
    # Get file path from command line or prompt
    if len(sys.argv) > 1:
        xml_file = sys.argv[1]
    else:
        xml_file = input("Enter XML file path: ")
    
    # Set batch size - smaller for safer processing
    batch_size = 1000
    
    # Parse the file
    success = parse_xml_file(xml_file, batch_size=batch_size)
    
    if success:
        print("XML processing completed successfully.")
    else:
        print("XML processing encountered errors. Check the logs above.")
