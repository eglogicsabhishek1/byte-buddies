import xml.sax
import time
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base

# Define Database Model using SQLAlchemy ORM
Base = declarative_base()

class Person(Base):
    __tablename__ = "people"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), default="")  # Store empty string if missing
    age = Column(Integer, nullable=True)  # Store NULL if missing
    weight = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)

# MySQL Database Connection (Change credentials accordingly)
DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"

engine = create_engine(DATABASE_URL, echo=False)
Base.metadata.create_all(engine)  # Create table if it doesn't exist

# Create a session
Session = sessionmaker(bind=engine)
session = Session()

# Load existing IDs from the database
existing_people = {p.id: p for p in session.query(Person).all()}

class PeopleHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.current_tag = ""
        self.person_id = None
        self.name = None
        self.age = None
        self.weight = None
        self.height = None
        self.seen_fields = set()  # Track seen tags
        self.people = []  # List for batch insert/update
        
        self.batch_size = 100000  # Bulk insert size
        self.start_time = time.time()  # Track start time
        self.last_insert_time = time.time()  # Track last batch insert time
        self.total_inserted = 0  # Count total records inserted
        self.last_update_time = time.time()  # Track last progress update time

    def startElement(self, name, attrs):
        self.current_tag = name
        if name == "person":
            self.person_id = int(attrs.get("id", "-1"))
            self.name = None
            self.age = None
            self.weight = None
            self.height = None
            self.seen_fields.clear()  # Reset seen fields for this person

    def characters(self, content):
        content = content.strip()
        if content:
            self.seen_fields.add(self.current_tag)  # Mark this tag as seen
            if self.current_tag == "name":
                self.name = content
            elif self.current_tag == "age":
                self.age = self.safe_int(content)
            elif self.current_tag == "weight":
                self.weight = self.safe_int(content)
            elif self.current_tag == "height":
                self.height = self.safe_int(content)

    def endElement(self, name):
        if name == "person" and self.person_id != -1:
            existing_person = existing_people.get(self.person_id)

            if existing_person:
                # Ensure missing fields remain unchanged in DB
                existing_person.name = self.name if "name" in self.seen_fields else existing_person.name
                existing_person.age = self.age if "age" in self.seen_fields else existing_person.age
                existing_person.weight = self.weight if "weight" in self.seen_fields else existing_person.weight
                existing_person.height = self.height if "height" in self.seen_fields else existing_person.height
            else:
                # New entry
                self.people.append(
                    Person(id=self.person_id, name=self.name or "", age=self.age, weight=self.weight, height=self.height)
                )

            self.total_inserted += 1  # Count records processed
            self.print_progress()

            # Bulk insert when batch size is reached
            if len(self.people) >= self.batch_size:
                self.insert_batch()

    def insert_batch(self):
        """Insert a batch of records into the database using SQLAlchemy ORM."""
        session.bulk_save_objects(self.people)
        session.commit()
        self.people.clear()  # Free memory
        
        # Track batch speed
        current_time = time.time()
        batch_time = current_time - self.last_insert_time
        batch_speed = self.batch_size / batch_time if batch_time > 0 else 0
        print(f"\n🔹 Batch inserted: {self.batch_size} records | Batch Speed: {batch_speed:.2f} records/sec")
        self.last_insert_time = current_time  # Reset last insert time

    def print_progress(self):
        """Print progress every second."""
        current_time = time.time()
        if current_time - self.last_update_time >= 1:
            elapsed_time = current_time - self.start_time
            speed = self.total_inserted / elapsed_time if elapsed_time > 0 else 0
            print(f"Records processed: {self.total_inserted} | Speed: {speed:.2f} records/sec", end="\r")
            self.last_update_time = current_time

    @staticmethod
    def safe_int(value):
        """Convert value to int, return None if invalid."""
        try:
            return int(value)
        except ValueError:
            return None

# Parse XML
handler = PeopleHandler()
parser = xml.sax.make_parser()
parser.setContentHandler(handler)
parser.parse("large_random_file_fast.xml")

# Final insert
if handler.people:
    handler.insert_batch()

session.commit()
elapsed_time = time.time() - handler.start_time
final_speed = handler.total_inserted / elapsed_time if elapsed_time > 0 else 0
print(f"\n✅ Data successfully inserted: {handler.total_inserted} records in {elapsed_time:.2f} sec")
print(f"📊 Final Average Speed: {final_speed:.2f} records/sec")

session.close()
