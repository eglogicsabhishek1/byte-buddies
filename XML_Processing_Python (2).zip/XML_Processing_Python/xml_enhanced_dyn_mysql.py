# import xml.sax
# import time
# from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table, inspect
# from sqlalchemy.orm import sessionmaker

# # Database setup
# DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"
# engine = create_engine(DATABASE_URL, echo=False)
# metadata = MetaData()
# session = sessionmaker(bind=engine)()
# inspector = inspect(engine)

# def create_table(table_name, columns):
#     """Dynamically create or retrieve a table with all required columns."""
#     metadata.reflect(engine)

#     if table_name in metadata.tables:
#         print(f"ℹ️ Table '{table_name}' already exists. Loading structure...")
#         return metadata.tables[table_name]

#     print(f"✅ Creating new table '{table_name}' with columns: {columns}")

#     table_columns = [Column("id", Integer, primary_key=True, autoincrement=True)]
#     table_columns += [Column(col, String(255), nullable=True) for col in columns if col != "id"]

#     table = Table(table_name, metadata, *table_columns)
#     metadata.create_all(engine)
#     return table

# class DynamicXMLHandler(xml.sax.ContentHandler):
#     def __init__(self):
#         self.current_tag = ""
#         self.current_data = {}
#         self.current_text = ""
#         self.table_name = "xml_data"
#         self.seen_columns = set()
#         self.records = []
#         self.batch_size = 200000
#         self.start_time = time.time()
#         self.last_insert_time = time.time()
#         self.total_inserted = 0
#         self.last_update_time = time.time()

#     def startElement(self, name, attrs):
#         """Handles opening tags."""
#         self.current_tag = name
#         self.current_text = ""  # Reset text buffer for this tag

#         # Store attributes as columns
#         for attr_name, attr_value in attrs.items():
#             self.current_data[attr_name] = attr_value
#             self.seen_columns.add(attr_name)

#     def characters(self, content):
#         """Handles text inside tags."""
#         content = content.strip()
#         if content:
#             self.current_text += content  # Append text to buffer

#     def endElement(self, name):
#         """Handles closing tags."""
#         if self.current_text:
#             self.current_data[name] = self.current_text  # Store tag content
#             self.seen_columns.add(name)

#         if name == "person":  # Store each 'person' tag as a new record
#             self.records.append(self.current_data.copy())
#             self.total_inserted += 1
#             self.print_progress()
#             self.current_data.clear()  # Reset data for next record

#             if len(self.records) >= self.batch_size:
#                 self.insert_batch()

#     def insert_batch(self):
#         """Insert records into the database."""
#         if not self.seen_columns or not self.records:
#             return

#         table = create_table(self.table_name, self.seen_columns)

#         # Convert lists to strings and filter empty records
#         valid_records = [
#             {key: str(value) if isinstance(value, list) else value for key, value in record.items()} 
#             for record in self.records if any(record.values())
#         ]

#         if valid_records:
#             try:
#                 session.execute(table.insert(), valid_records)
#                 session.commit()
#                 print(f"\n✅ Inserted {len(valid_records)} records successfully!")
#             except Exception as e:
#                 print(f"\n❌ Database Error: {e}")
#                 session.rollback()

#             self.records.clear()
#             self.last_insert_time = time.time()

#     def print_progress(self):
#         """Displays progress every second."""
#         current_time = time.time()
#         if current_time - self.last_update_time >= 1:
#             elapsed_time = current_time - self.start_time
#             speed = self.total_inserted / elapsed_time if elapsed_time > 0 else 0
#             print(f"⏳ Processed: {self.total_inserted} records | Speed: {speed:.2f} records/sec", end="\r")
#             self.last_update_time = current_time

# # XML Parsing
# handler = DynamicXMLHandler()
# parser = xml.sax.make_parser()
# parser.setContentHandler(handler)

# xml_file = "large_random_file_fast.xml"

# try:
#     parser.parse(xml_file)
# except Exception as e:
#     print(f"\n❌ Error while parsing XML: {e}")

# if handler.records:
#     handler.insert_batch()

# session.commit()
# elapsed_time = time.time() - handler.start_time
# final_speed = handler.total_inserted / elapsed_time if elapsed_time > 0 else 0
# print(f"\n✅ Data successfully inserted: {handler.total_inserted} records in {elapsed_time:.2f} sec")
# print(f"📊 Final Average Speed: {final_speed:.2f} records/sec")

# session.close()

import xml.sax
import time
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table, inspect
from sqlalchemy.orm import sessionmaker
from collections import OrderedDict  # ✅ Ensures tag order is preserved

# Database setup
DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"
engine = create_engine(DATABASE_URL, echo=False)
metadata = MetaData()
session = sessionmaker(bind=engine)()
inspector = inspect(engine)

def create_table(table_name, columns):
    """Dynamically create or retrieve a table with all required columns."""
    metadata.reflect(engine)

    if table_name in metadata.tables:
        print(f"ℹ️ Table '{table_name}' already exists. Loading structure...")
        return metadata.tables[table_name]

    print(f"✅ Creating new table '{table_name}' with columns: {columns}")

    table_columns = [Column("id", Integer, primary_key=True, autoincrement=True)]
    table_columns += [Column(col, String(255), nullable=True) for col in columns if col != "id"]

    table = Table(table_name, metadata, *table_columns)
    metadata.create_all(engine)
    return table

class DynamicXMLHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.current_tag = ""
        self.current_data = OrderedDict()  # ✅ Preserve tag order
        self.current_text = ""
        self.table_name = "xml_data"
        self.seen_columns = []
        self.records = []
        self.batch_size = 300000
        self.start_time = time.time()
        self.last_insert_time = time.time()
        self.total_inserted = 0
        self.last_update_time = time.time()

    def startElement(self, name, attrs):
        """Handles opening tags."""
        self.current_tag = name
        self.current_text = ""  # Reset text buffer for this tag

        # Store attributes as columns (ensure order is maintained)
        for attr_name, attr_value in attrs.items():
            if attr_name not in self.seen_columns:
                self.seen_columns.append(attr_name)
            self.current_data[attr_name] = attr_value

    def characters(self, content):
        """Handles text inside tags."""
        content = content.strip()
        if content:
            self.current_text += content  # Append text to buffer

    def endElement(self, name):
        """Handles closing tags."""
        if self.current_text:
            if name not in self.seen_columns:
                self.seen_columns.append(name)
            self.current_data[name] = self.current_text  # ✅ Store tag content in order

        if name == "person":  # Store each 'person' tag as a new record
            self.records.append(self.current_data.copy())  # ✅ OrderedDict ensures correct order
            self.total_inserted += 1
            self.print_progress()
            self.current_data.clear()  # Reset data for next record

            if len(self.records) >= self.batch_size:
                self.insert_batch()

    def insert_batch(self):
        """Insert records into the database."""
        if not self.seen_columns or not self.records:
            return

        table = create_table(self.table_name, self.seen_columns)

        # Convert lists to strings and filter empty records
        valid_records = [
            {key: str(value) if isinstance(value, list) else value for key, value in record.items()} 
            for record in self.records if any(record.values())
        ]

        if valid_records:
            try:
                session.execute(table.insert(), valid_records)
                session.commit()
                print(f"\n✅ Inserted {len(valid_records)} records successfully!")
            except Exception as e:
                print(f"\n❌ Database Error: {e}")
                session.rollback()

            self.records.clear()
            self.last_insert_time = time.time()

    def print_progress(self):
        """Displays progress every second."""
        current_time = time.time()
        if current_time - self.last_update_time >= 1:
            elapsed_time = current_time - self.start_time
            speed = self.total_inserted / elapsed_time if elapsed_time > 0 else 0
            print(f"⏳ Processed: {self.total_inserted} records | Speed: {speed:.2f} records/sec", end="\r")
            self.last_update_time = current_time

# XML Parsing
handler = DynamicXMLHandler()
parser = xml.sax.make_parser()
parser.setContentHandler(handler)

xml_file = "large_random_file_fast.xml"

try:
    parser.parse(xml_file)
except Exception as e:
    print(f"\n❌ Error while parsing XML: {e}")

if handler.records:
    handler.insert_batch()

session.commit()
elapsed_time = time.time() - handler.start_time
final_speed = handler.total_inserted / elapsed_time if elapsed_time > 0 else 0
print(f"\n✅ Data successfully inserted: {handler.total_inserted} records in {elapsed_time:.2f} sec")
print(f"📊 Final Average Speed: {final_speed:.2f} records/sec")

session.close()
