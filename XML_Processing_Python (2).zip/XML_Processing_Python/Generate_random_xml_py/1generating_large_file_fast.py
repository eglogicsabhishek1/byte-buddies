import random

# List of names to choose from
names = ["John Doe", "Jane Smith", "Alice Johnson", "Bob Brown", "Charlie Davis", "Diana Prince", "Clark Kent", "Bruce Wayne", "Peter Parker", "Tony Stark"]

def generate_person_xml(id):
    """Generate XML for a single person as a string (no in-memory storage)."""
    return f'''  <person id="{id}">
    <name>{random.choice(names)}</name>
    <age>{random.randint(18, 80)}</age>
    <weight>{random.randint(50, 150)}</weight>
    <height>{random.randint(150, 220)}</height>
  </person>\n'''

def generate_large_xml_file(file_path, num_persons):
    """Generate and write XML file directly to disk in chunks (faster)."""
    with open(file_path, "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<group>\n')  # Start XML
        
        for i in range(1, num_persons + 1):
            f.write(generate_person_xml(i))  # Write each person directly
            
            if i % 100000 == 0:  # Print progress every 100,000 records
                print(f"Generated {i} records...")
        
        f.write('</group>\n')  # End XML

# Generate a large XML file with 10,000,000 records
generate_large_xml_file("large_random_file_fast.xml", 10000000)

print("✅ XML file generated successfully!")
