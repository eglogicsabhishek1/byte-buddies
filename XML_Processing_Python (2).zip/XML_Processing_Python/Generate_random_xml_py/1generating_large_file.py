import random
import xml.etree.ElementTree as ET

# List of names to choose from
names = ["John Doe", "Jane Smith", "Alice Johnson", "Bob Brown", "Charlie Davis", "Diana Prince", "Clark Kent", "Bruce Wayne", "Peter Parker", "Tony Stark"]

def generate_random_person(id):
    person = ET.Element("person", attrib={"id": str(id)})
    name = ET.SubElement(person, "name")
    name.text = random.choice(names)
    age = ET.SubElement(person, "age")
    age.text = str(random.randint(18, 80))
    weight = ET.SubElement(person, "weight")
    weight.text = str(random.randint(50, 150))
    height = ET.SubElement(person, "height")
    height.text = str(random.randint(150, 220))
    return person

def generate_large_random_xml_file(file_path, num_persons):
    group = ET.Element("group")
    for i in range(1, num_persons + 1):
        group.append(generate_random_person(i))
    
    tree = ET.ElementTree(group)
    tree.write(file_path, encoding="utf-8", xml_declaration=True)

# Generate a large XML file with 100,000 <person> elements
generate_large_random_xml_file("large_random_file1.xml", 10000000)