import xml.sax
import mysql.connector

# Connect to MySQL database
conn = mysql.connector.connect(
    host="127.0.0.1",      # Change to your MySQL server host (e.g., 127.0.0.1)
    user="root",      # Replace with your MySQL username
    password="Ritik@123",  # Replace with your MySQL password
    database="demo"   # Replace with your MySQL database name
)
cursor = conn.cursor()

# Create table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS people (
        id INT PRIMARY KEY,
        name VARCHAR(255),
        age INT,
        weight INT,
        height INT
    )
''')
conn.commit()  # Commit the table creation

class PeopleHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.current = ""
        self.person_id = None
        self.name = ""
        self.age = ""
        self.weight = ""
        self.height = ""

    def startElement(self, name, attrs):
        self.current = name
        if name == "person":
            self.person_id = int(attrs["id"])  # Convert ID to integer

    def characters(self, content):
        if self.current == "name":
            self.name = content.strip()
        elif self.current == "age":
            self.age = int(content.strip())  # Convert to integer
        elif self.current == "weight":
            self.weight = int(content.strip())  # Convert to integer
        elif self.current == "height":
            self.height = int(content.strip())  # Convert to integer

    def endElement(self, name):
        if name == "height":  # Last element of a person entry
            cursor.execute('''
                INSERT INTO people (id, name, age, weight, height) 
                VALUES (%s, %s, %s, %s, %s)
            ''', (self.person_id, self.name, self.age, self.weight, self.height))
            conn.commit()  # Commit the changes immediately
        self.current = ""

# Parse the XML file
handler = PeopleHandler()
parser = xml.sax.make_parser()
parser.setContentHandler(handler)
parser.parse("large_random_file.xml")

# Close the database connection
cursor.close()
conn.close()
