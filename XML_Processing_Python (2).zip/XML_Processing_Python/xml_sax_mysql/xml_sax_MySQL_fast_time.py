import xml.sax
import mysql.connector
import time

# Connect to MySQL database
conn = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="Ritik@123",
    database="demo1"
)
cursor = conn.cursor()

# Create table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS people (
        id INT PRIMARY KEY,
        name VARCHAR(255),
        age INT,
        weight INT,
        height INT
    )
''')
conn.commit()  # Commit table creation

class PeopleHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.current = ""
        self.person_id = None
        self.name = ""
        self.age = ""
        self.weight = ""
        self.height = ""
        self.people = []  # List to store data before bulk insert
        self.batch_size = 50000  # Adjust batch size for better performance
        self.total_inserted = 0  # Total records inserted
        self.start_time = time.time()  # Track start time

    def startElement(self, name, attrs):
        self.current = name
        if name == "person":
            self.person_id = int(attrs["id"])  

    def characters(self, content):
        if self.current == "name":
            self.name = content.strip()
        elif self.current == "age":
            self.age = int(content.strip())  
        elif self.current == "weight":
            self.weight = int(content.strip())  
        elif self.current == "height":
            self.height = int(content.strip())  

    def endElement(self, name):
        if name == "height":  # Last element of a person entry
            self.people.append((self.person_id, self.name, self.age, self.weight, self.height))

            if len(self.people) >= self.batch_size:  # Insert when batch size is reached
                self.insert_batch()

        self.current = ""

    def insert_batch(self):
        """Inserts a batch of records and tracks speed."""
        global cursor, conn
        cursor.executemany('''
            INSERT IGNORE INTO people (id, name, age, weight, height) 
            VALUES (%s, %s, %s, %s, %s)
        ''', self.people)
        conn.commit()

        # Speed tracking
        batch_time = time.time() - self.start_time
        self.total_inserted += len(self.people)
        speed = self.total_inserted / batch_time  # Records per second
        print(f"Inserted {self.total_inserted} records... Speed: {speed:.2f} records/sec")

        self.people = []  # Clear the list after inserting

# Parse the XML file
handler = PeopleHandler()
parser = xml.sax.make_parser()
parser.setContentHandler(handler)
parser.parse("large_random_file_fast.xml")

# Insert remaining data (if any)
if handler.people:
    handler.insert_batch()

# Final speed report
total_time = time.time() - handler.start_time
print(f"✅ Total Records Inserted: {handler.total_inserted}")
print(f"⏳ Total Time Taken: {total_time:.2f} seconds")
print(f"⚡ Average Speed: {handler.total_inserted / total_time:.2f} records/sec")

# Close the database connection
cursor.close()
conn.close()
