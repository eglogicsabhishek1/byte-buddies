import xml.sax
import time
import re
import hashlib
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table, text
from sqlalchemy.orm import sessionmaker
from collections import OrderedDict

# Database Connection
DATABASE_URL = "mysql+mysqlconnector://root:Ritik%40123@127.0.0.1/xml_data"
engine = create_engine(DATABASE_URL, echo=False)
metadata = MetaData()
session = sessionmaker(bind=engine)()

# Sanitize column/table names to prevent SQL errors
def sanitize_name(name):
    name = re.sub(r'\W+', '_', name.lower())
    if len(name) > 60:
        hash_suffix = hashlib.md5(name.encode()).hexdigest()[:8]  # Unique short hash
        name = name[:52] + "_" + hash_suffix  # Keep under 64-char limit
    return name

# Create or update table dynamically
def create_or_update_table(table_name, columns):
    """Creates or updates table dynamically if needed"""
    table_name = sanitize_name(table_name)
    metadata.reflect(engine)

    if table_name in metadata.tables:
        table = metadata.tables[table_name]
        existing_columns = set(table.columns.keys())
        new_columns = set(sanitize_name(col) for col in columns)  # Sanitize column names
        missing_columns = new_columns - existing_columns

        # Add missing columns dynamically
        if missing_columns:
            with engine.connect() as conn:
                for col in missing_columns:
                    if col not in existing_columns and col != "id":  # Check before adding
                        alter_stmt = text(f"ALTER TABLE `{table_name}` ADD COLUMN `{col}` VARCHAR(255)")
                        try:
                            conn.execute(alter_stmt)
                            print(f"Added column: {col}")
                        except Exception as e:
                            print(f"⚠️ Error adding column `{col}`: {e}")
            metadata.reflect(engine)
        return metadata.tables[table_name]

    print(f"🔹 Creating table: {table_name}")
    
    # Sanitize all column names before creating table
    sanitized_columns = {sanitize_name(col): col for col in columns}
    
    table_columns = [Column("id", Integer, primary_key=True, autoincrement=True)]
    # Ensure we don't create duplicate columns
    for col in sanitized_columns.keys():
        if col != "id" and col != "record_hash":
            table_columns.append(Column(col, String(255), nullable=True))
    
    table_columns.append(Column("record_hash", String(32), unique=True))  # Unique hash for tracking changes

    table = Table(table_name, metadata, *table_columns)
    metadata.create_all(engine)
    return table

# XML Parser with Update Support and better deep nesting handling
class DynamicXMLHandler(xml.sax.ContentHandler):
    def __init__(self):
        super().__init__()
        self.path = []  # Track XML path for nested elements
        self.current_record = OrderedDict()
        self.tables = {}
        self.total_inserted = 0
        self.start_time = time.time()
        self.root_element = None  # Store the root element
        self.current_text = ""
        self.depth = 0  # Track depth for nested elements

    def startElement(self, name, attrs):
        """Handles opening XML tags"""
        self.depth += 1
        if not self.root_element:
            self.root_element = name  # Set root element on first encounter
        self.path.append(name)  # Track nesting
        
        # Reset current text when starting a new element
        self.current_text = ""
        
        # Process attributes
        for attr_name, attr_value in attrs.items():
            key = f"{'_'.join(self.path)}@{attr_name}"
            self.current_record[key] = attr_value

    def characters(self, content):
        """Handles text inside tags"""
        # Accumulate text content
        self.current_text += content

    def endElement(self, name):
        """Handles closing XML tags"""
        # Process accumulated text for this element
        if self.current_text.strip():
            path_str = "_".join(self.path)
            self.current_record[path_str] = self.current_text.strip()
        
        # Save record when closing a second-level element (direct child of root)
        if self.depth == 2:  # Second level element
            table_name = self.root_element
            
            # Ensure all sanitized keys
            sanitized_record = {}
            for key, value in self.current_record.items():
                sanitized_key = sanitize_name(key)
                sanitized_record[sanitized_key] = value
            
            # Create or update table with all columns
            if table_name not in self.tables or len(self.tables[table_name].columns) < len(sanitized_record) + 2:  # +2 for id and record_hash
                self.tables[table_name] = create_or_update_table(table_name, sanitized_record.keys())
            
            # Generate a unique hash for the record
            record_hash = hashlib.md5(str(sanitized_record).encode()).hexdigest()
            sanitized_record["record_hash"] = record_hash
            
            # Ensure we only use columns that exist in the table
            valid_columns = set(c.name for c in self.tables[table_name].columns)
            valid_record = {k: v for k, v in sanitized_record.items() if k in valid_columns}
            
            # Check if record already exists
            existing = session.execute(
                self.tables[table_name].select().where(self.tables[table_name].c.record_hash == record_hash)
            ).fetchone()
            
            try:
                if existing:
                    session.execute(
                        self.tables[table_name].update()
                        .where(self.tables[table_name].c.record_hash == record_hash)
                        .values(valid_record)
                    )
                else:
                    session.execute(self.tables[table_name].insert().values(valid_record))
                
                self.total_inserted += 1
            except Exception as e:
                print(f"Error inserting/updating record: {e}")
                session.rollback()
            
            # Clear current record after processing
            self.current_record = OrderedDict()
        
        # Reset and pop path
        self.current_text = ""
        self.path.pop()
        self.depth -= 1

# Main processing
handler = DynamicXMLHandler()
parser = xml.sax.make_parser()
parser.setContentHandler(handler)

xml_file = "bank.xml"  # Replace with your XML file

try:
    # Commit transaction in batches for better performance
    session.begin()
    parser.parse(xml_file)
    session.commit()
except Exception as e:
    session.rollback()
    print(f"\n❌ Error while parsing XML: {e}")

elapsed_time = time.time() - handler.start_time
final_speed = handler.total_inserted / elapsed_time if elapsed_time > 0 else 0
print(f"\n✅ Data successfully inserted/updated: {handler.total_inserted} records in {elapsed_time:.2f} sec")
print(f"📊 Final Average Speed: {final_speed:.2f} records/sec")

session.close()