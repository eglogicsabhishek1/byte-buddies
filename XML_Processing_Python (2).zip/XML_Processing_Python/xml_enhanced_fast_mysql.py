import xml.etree.cElementTree as ET
import time

XML_FILE = "large_random_file_fast.xml"

def parse_large_xml(file_path):
    """Fast streaming XML parser"""
    start_time = time.time()
    total_records = 0

    # Use a fast XML streaming parser
    for event, elem in ET.iterparse(file_path, events=("start", "end")):
        if event == "start" and elem.tag == "person":
            person_id = int(elem.attrib.get("id", "-1"))
            name = elem.findtext("name", default="")
            age = safe_int(elem.findtext("age"))
            weight = safe_int(elem.findtext("weight"))
            height = safe_int(elem.findtext("height"))

            total_records += 1
            print_progress(total_records, start_time)

        # Clear element to free memory
        elem.clear()

    elapsed_time = time.time() - start_time
    print(f"\n✅ Finished parsing {total_records} records in {elapsed_time:.2f} sec")
    print(f"📊 Parsing Speed: {total_records / elapsed_time:.2f} records/sec")

def print_progress(count, start_time):
    """Print progress every second"""
    current_time = time.time()
    elapsed = current_time - start_time
    if elapsed > 0:
        speed = count / elapsed
        print(f"Records processed: {count} | Speed: {speed:.2f} records/sec", end="\r")

def safe_int(value):
    """Convert value to int, return None if invalid"""
    try:
        return int(value)
    except (ValueError, TypeError):
        return None

# Run parser
parse_large_xml(XML_FILE)
